<div id="openedProduct-img">
    <img src="<?php echo $good['img']; ?>">
    </div>
            <div id="openedProduct-content">
    <h1 id="openedProduct-name">
        <?php echo $good['name']; ?>
    </h1>
    <div id="openedProduct-desc">
        <?php echo $good['desc']; ?>
    </div>
    <div id="openedProduct-price">
                    Цена: <?php echo $good['price']; ?>
    </div>
</div>